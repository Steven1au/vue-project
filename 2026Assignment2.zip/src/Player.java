/**
 * Model the player
 */
public class Player {
    /**
     * The length of the list
     */
    private static final int LIST_LENGTH = 6;
    /**
     * A secret list of a player. This list would not be changed during the game
     */
    private Character[] myList;
    /**
     * The number of veto (reject) voting card. Decrement it when the player vote
     * reject.
     */
    private int vetoCard;
    /**
     * The name of the player.
     */
    private String name;

    /**
     * Compute the score of a player. Each player should have a list of character
     *
     * @return the score of a player.
     */
    public int getScore() {

        int score = 0;
        for (int i = 0; i < myList.length; i++) {
            int position = myList[i].getPosition();
            if (position != -1) {
                score = score + Gameboard.SCORES[position];
            }
        }
        return score;
    }

    /**
     * Return the name of a player.
     *
     * @return the name of the player
     */
    public String getName() {

        return this.name;
    }

    /**
     * Initialize the number of veto card
     *
     * @param card the number of veto card
     */
    public void initVetoCard(int card) {

        this.vetoCard = card;
    }

    /**
     * Initialize all data attributes.
     *
     * @param name the name of the player
     * @param list a whole list of characters and the player should pick
     *             LIST_LENGTH of <b>unique</b> characters
     */
    public Player(String name, Character[] list) {

        this.name = name;
        this.myList = list;
    }

    /**
     * A method to vote according to the preference of the parameter support.
     * A player is forced to vote yes (support) if he/she has no more veto card.
     *
     * @param support The preference of the player
     * @return true if the player support it. False if the player reject (veto).
     */
    public boolean vote(boolean support) {

        if (vetoCard == 0) {
            return true;
        }
        if (support) {
            return true;
        }

        vetoCard = vetoCard - 1;
        return false;
    }

    /**
     * Vote randomly. The player will be forced to vote support(true) if he is
     * running out of veto card.
     *
     * @return true if the player support it. False if the player reject (veto).
     */
    public boolean voteRandomly() {

        if (vetoCard == 0) {
            return true;
        }

        int v = (int) (Math.random() * 10);
        if (v < 5) {
            return vote(true);
        }
        vetoCard--;
        return vote(false);

    }

    /**
     * Randomly place a character during the placing stage. This method should pick a
     * random unplaced character and place it to a random valid position.
     *
     * @param list The list of all characters. Some of these characters may have been
     *             placed already
     * @return the character that just be placed.
     */
    public Character placeRandomly(Character[] list) {

        int i = (int) (Math.random() * list.length);

        return list[i];
    }

    /**
     * The player shall vote smartly (i.e., its decision will be based on if the player has that
     * character in his/her list.) If the player is running out of veto card, he/she will be forced
     * to vote support (true).
     *
     * @param character The character that is being vote.
     * @return true if the player support, false if the player reject(veto).
     */
    public boolean voteSmartly(Character character) {

        if (vetoCard == 0) {
            return true;
        }

        for (int i = 0; i < myList.length; i++) {
            if (myList[i].getName().equals(character.getName())) {
                vetoCard--;
                return false;
            }
        }

        return true;
    }

    /**
     * The player shall pick a randomly character that is <i>movable</i> during the playing stage.
     * Movable means the character has not yet be killed and the position right above it is not full.
     * <p>
     * Note: this method should not change the position of the character.
     *
     * @param list The entire list of characters
     * @return the character being picked to move. It never returns null.
     */
    public Character pickCharToMoveRandomly(Character[] list) {

        int cha;
        Character character = null;
        int position;
        while (true) {
            cha = (int) (Math.random() * Gameboard.NO_OF_CHARACTER);
            character = list[cha];
            position = character.getPosition();
            if (position == -1) {       // be killed
                continue;
            }
            if (!Gameboard.isFull(position + 1)) {      //not full
                break;
            }
        }

        return character;
    }

    /**
     * This method return the character who's name is the same as the
     * variable name if the character is <i>movable</i>. Movable means
     * the character has not yet be killed and the position right above
     * it is not full.
     * <p>
     * If the name of the character can't be found from the list or the
     * character is not movable, this method returns null.
     * <p>
     * Note: this method should not change the position of the character.
     *
     * @param list The entire list of characters
     * @param name The name of the character being picked.
     * @return the character being picked to move or null if the character
     * can't be found or the it is not movable.
     */
    public Character pickCharToMove(Character[] list, String name) {

        if (list == null || list.length == 0) {
            return null;
        }
        for (int i = 0; i < list.length; i++) {
            if (list[i] == null) {
                continue;
            }
            if (list[i].getName().equals(name)) {
                Character character = list[i];
                int position = character.getPosition();
                if (position == -1) {  // killed
                    return null;
                }
                if (Gameboard.isFull(position + 1)) {      //full
                    return null;
                }
                return list[i];
            }
        }

        return null;
    }

    /**
     * Similar to pickCharToMoveRandomly only as the character being picked to move
     * is related to the secret list of the player. The implementation of this part is
     * open and you are advised to optimize it to increase the chance of winning.
     * <p>
     * Note: this method should not change the position of the character.
     *
     * @param list The list of character
     * @return the character to be move. It never returns null.
     */
    public Character pickCharToMoveSmartly(Character[] list) {

        int exist = 0;
        for (int floor = 5; floor >= 0; floor--) {
            for (int index = 0; index < Gameboard.NO_OF_CHARACTER; index++) {
                if (list[index].getPosition() == floor) {
                    exist = 0;
                    for (int i = 0; i < myList.length; i++) {
                        if (list[index].getName().equals(myList[i].getName())) {
                            exist = 1;
                            break;
                        }
                    }
                    if (exist == 0) {
                        if (vetoCard > 0) {
                            return list[index];
                        }
                    } else {
                        if (vetoCard == 0) {
                            return list[index];
                        }
                    }
                }
            }
        }

        return null;
    }

    /**
     * This returns the name of the player and the secret list of the characters.
     * as a string
     *
     * @return The name of the player followed by the secret list of the characters.
     */
    public String toString() {


        String ans = name + "    Veto Card :" + vetoCard + "\n";

        for (int i = 0; i < myList.length; i++) {
            ans = ans + myList[i] + "   ";
        }
        return ans;
    }
}

