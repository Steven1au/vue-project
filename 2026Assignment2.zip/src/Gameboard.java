import java.util.Scanner;

/**
 * The class Gameboard is to print control the flow of the game and
 * contains a set of players and characters.
 */
public class Gameboard {

    /**
     * The maximum number of characters can be placed in the same position.
     */
    public static final int FULL = 4;
    /**
     * The total number of characters
     */
    public static final int NO_OF_CHARACTER = 13;
    /**
     * The total number of player
     */
    public static final int NO_OF_PLAYERS = 4;
    /**
     * The position of Throne
     */
    public static final int THRONE = 6;
    /**
     * The scores calculation formula
     */
    public static final int[] SCORES = {0, 1, 2, 3, 4, 5, 10};
    /**
     * The name of the characters
     */
    public static final String[] CHARACTER_NAMES = {
            "Aligliero", "Beatrice", "Clemence", "Dario",
            "Ernesto", "Forello", "Gavino", "Irima",
            "Leonardo", "Merlino", "Natale", "Odessa", "Piero"
    };
    /**
     * The name of the players
     */
    public static final String[] PLAYER_NAMES = {
            "You", "Computer 1", "Computer 2", "Computer 3"
    };
    /**
     * Determine if the players are human player or not.
     */
    public static final boolean[] HUMAN_PLAYERS = {
            true, false, false, false
    };
    /**
     * A list of character
     */
    private static Character[] characters;
    /**
     * A list of player
     */
    private static Player[] players;

    /**
     * gameboard
     */
//    public static String[][] gameBoard=new String[THRONE+1][FULL];
    public static void main(String[] argv) {
        new Gameboard().runOnce();
    }

    /**
     * Initialize all data attributes. You will need to initialize and create
     * the array players and characters. You should initialize them using the
     * String array PLAYER_NAMES and CHARACTER_NAMES respectively.
     */
    public Gameboard() {


        // Initialize characters
        characters = new Character[NO_OF_CHARACTER];
        for (int i = 0; i < NO_OF_CHARACTER; i++) {
            characters[i] = new Character(CHARACTER_NAMES[i]);
        }

        // Initialize players
        players = new Player[NO_OF_PLAYERS];
        for (int i = 0; i < NO_OF_PLAYERS; i++) {
            Character[] tempCharacters = new Character[Gameboard.NO_OF_CHARACTER];
            for (int j = 0; j < Gameboard.NO_OF_CHARACTER; j++) {
                tempCharacters[j] = characters[j];
            }
            Character[] myList = new Character[6];
            int n = NO_OF_CHARACTER;
            for (int j = 0; j < 6; j++) {
                int temp = (int) (Math.random() * n);
                myList[j] = tempCharacters[temp];
                tempCharacters[temp] = tempCharacters[n - 1];
                n = n - 1;
            }
            players[i] = new Player(PLAYER_NAMES[i], myList);
            players[i].initVetoCard(3);
        }
    }

    /**
     * The main logic of the game. This part has been done for you.
     */
    public void runOnce() {

        print();
        System.out.println("======= Placing stage ======= \n"
                + "Each player will take turns to place three characters on the board.\n"
                + "No character can be placed in the position 0 or 5 or 6 (Throne) at this stage.\n"
                + "A position is FULL when there are four characters placed there already.\n"
                + "The remaining character will be placed at the position 0.\n");

        placingStage();

        print();
        System.out.println("======= Playing stage ======= \n"
                + "Each player will take turn to move a character UP the board.\n"
                + "You cannot move a character that is been killed or its immediate upper position is full.\n"
                + "A voting will be trigger immediately when a character is moved to the Throne (position 6).");

        playingStage();

        print();
        System.out.println("======= Scoring stage ======= \n"
                + "This will trigger if and only if the voting result is ALL positive, i.e., no player play the veto (reject) card. \n"
                + "The score of each player is computed by the secret list of characters owned by each player.");

        scoringStage();
    }


    /**
     * Print the scores of all players correctly. This part has been done
     * for you.
     */
    private void scoringStage() {
        for (Player p : players) {
            System.out.println(p);
            System.out.println("Score: " + p.getScore());
        }
    }

    /**
     * Perform the placing stage. You have to be careful that human player will need to chosen on what to place
     * Non-human player will need to place it using the method placeRandomly (see Player.java)
     */
    private void placingStage() {

        Scanner in = new Scanner(System.in);
        int index;
        int floor;
        for (int i = 0; i < 12; i++) {
            print();
            System.out.print(players[i % 4].toString());
            System.out.println(", this is your turn to place a character");
            // human player
            if (HUMAN_PLAYERS[i % 4]) {
                String characterName;
                do {
                    System.out.println("Please pick a character");
                    characterName = in.next();
                    for (index = 0; index < Gameboard.NO_OF_CHARACTER; index++) {
                        if (characters[index].getName().equals(characterName)) {
                            if (characters[index].getPosition() == -1) {
                                break;
                            }
                        }
                    }
                } while (index == Gameboard.NO_OF_CHARACTER);


                do {
                    System.out.println("Please enter the floor you want to place Beatrice");
                    floor = in.nextInt();
                } while (isFull(floor) || (floor < 1 || floor > 4));
            } else {
                // computer player
                while (true) {
                    index = (int) (Math.random() * NO_OF_CHARACTER);
                    if (characters[index].getPosition() == -1) {
                        break;
                    }
                }
                do {
                    floor = (int) (Math.random() * 4) + 1;
                } while (isFull(floor));
            }

            // set the position of the character.
            characters[index].setPosition(floor);

        }

        //and place the last character at position 0
        for (int i = 0; i < NO_OF_CHARACTER; i++) {
            if (characters[i].getPosition() == -1) {
                characters[i].setPosition(0);
                break;
            }
        }


    }


    /**
     * Perform playing stage. Be careful that human player will need to pick the character to move.
     * You should detect any invalid input and stop human player from doing something nonsense or illegal.
     * Computer players will need to run the code pickCharToMoveRandomly or pickCharToMoveSmartly to pick which character to move.
     */
    private void playingStage() {

        Scanner in = new Scanner(System.in);
        int step = 0;
        String characterName;
        Character character;
        while (true) {
            print();
            System.out.println(players[step % 4].toString());
            System.out.println("This is your turn to move a character up");
            character = null;
            if (step % 4 == 0) {
                while (character == null) {
                    System.out.println("Please type the character that you want to move.");
                    characterName = in.next();
                    character = players[0].pickCharToMove(characters, characterName);
                }
            } else {
                character = players[step % 4].pickCharToMoveSmartly(characters);
                while (character == null) {
                    character = players[step % 4].pickCharToMoveRandomly(characters);
                }
            }

            // move
            int index = 0;
            for (int i = 0; i < NO_OF_CHARACTER; i++) {
                if (characters[i].getName().equals(character.getName())) {
                    index = i;
                    break;
                }
            }
            characters[index].setPosition(characters[index].getPosition() + 1);
            if (characters[index].getPosition() == THRONE) {
                print();
                int vote = 0;
                for (int i = 0; i < NO_OF_PLAYERS; i++) {
                    if (i == 0) {
                        System.out.println("Please vote. Type V for veto. Other for accept");
                        String v = in.next();
                        boolean v1 = players[0].vote(!v.equals("V"));
                        if (!v1) {
                            vote = vote + 1;
                        }
                        continue;
                    }
                    boolean v2 = players[i % 4].voteSmartly(characters[index]);
                    if (!v2) {
                        vote = vote + 1;
                    }
                }
                if (vote == 0) {
                    break;
                } else {
                    characters[index].setPosition(-1);
                }
            }
            step = step + 1;
        }

    }


    /**
     * Print the gameboard. Please see the assignment webpage or the demo program for
     * the format. You should call this method after a character has been moved or placed or killed.
     */
    private void print() {
        for (int i = THRONE; i >= 0; i--) {
            System.out.print("Level " + i + ":");
            for (int j = 0; j < NO_OF_CHARACTER; j++) {
                if (characters[j].getPosition() == i) {
                    System.out.print("  " + characters[j].getName());
                }
            }
            System.out.println();
        }
        System.out.println("Unplaced/Killed Characters");
        for (int i = 0; i < NO_OF_CHARACTER; i++) {
            if (characters[i].getPosition() != -1) {
                continue;
            }
            System.out.print(characters[i].toString() + "   ");
        }
        System.out.println();
        System.out.println();

    }

    public static boolean isFull(int floor) {
        int count = 0;
        for (int index = 0; index < NO_OF_CHARACTER; index++) {
            if (characters[index].getPosition() == floor) {
                count = count + 1;
            }
        }
        return count >= FULL;
    }

}
