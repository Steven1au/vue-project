/**
 * If the owner owns only one train station, the rent is 500
 * If the owner owns two of them, the rent is 1000
 * If the owner owns three of them, the rent is 2000
 * If the owner owns four of them, the rent is 4000
 */
public class TrainStationPropertyCell extends PropertyCell {
	
    public TrainStationPropertyCell(String name, int baseCost) {
		super(name, baseCost);
	}
	public TrainStationPropertyCell(String name) {
		super(name, TRAIN_STATION_COST);
	}
	public static final int TRAIN_STATION_COST = 500;
    public static final TrainStationPropertyCell[] TRAIN_STATION_ARRAY = {
            new TrainStationPropertyCell("Kowloon"),
            new TrainStationPropertyCell("Mongkok"),
            new TrainStationPropertyCell("Central"),
            new TrainStationPropertyCell("Shatin")
    };
    
    @Override
	public void hasOwnerEvent(Player p) {
    	if(!owner.getName().equals(p.getName())) {
			if(this.owner.isInPark() == true) {
				System.out.println(this.owner.getName() + " is in the Park. Free parking.");
		        return;
			}
			int payRent = this.getRent(p);
			System.out.println(p.getName() + " have paid " +this.owner.getName() + " $" + payRent);
		}
	}


    
    @Override
    public int getRent(Player p) {
    	int temp = 0;
    	for (int i = 0; i < TRAIN_STATION_ARRAY.length; i++) {
			if(TRAIN_STATION_ARRAY[i].owner != null && TRAIN_STATION_ARRAY[i].owner.getName().equals(this.owner.getName())) {
				temp ++ ;
			}
		}
    	switch (temp) {
		case 1:
			p.charge(500);
			owner.charge(-500);
			return 500;
		case 2:
			p.charge(1000);
			owner.charge(-1000);
			return 1000;
		case 3:
			p.charge(2000);
			owner.charge(-2000);
			return 2000;
		case 4:
			p.charge(4000);
			owner.charge(-4000);
			return 4000;
		default:
			break;
		}
    	return 0;
    }
    //TODO add some other methods if necessary
 
}
