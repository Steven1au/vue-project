import java.util.concurrent.ThreadLocalRandom;

/**
 * Got one of the following chances randomly:
 * 1. Roll again
 * 2. +1000
 * 3. -1000
 * 4. Move to Jail directly without getting the 2000.
 */
public class ChanceCell extends FunctionCell {

	public ChanceCell(String name) {
		super(name);
	}

	@Override
	public void event(Player p, Cell[] cells) {
		switch (ThreadLocalRandom.current().nextInt(0, 4)) {
	      case 0:
	        System.out.println(this.name + " result: Roll again!");
	        p.roll();
	        break;
	      case 1:
	        System.out.println(this.name + " result: Gain $1000!");
	        p.charge(-1000);
	        break;
	      case 2:
	        System.out.println(this.name + " result: Deduct $1000!");
	        p.charge(1000);
	        break;
	      case 3:
	        p.putToJail();
	        System.out.println(this.name + " result: Go to Jail, now!");
	        break;
	    } 
	}

}