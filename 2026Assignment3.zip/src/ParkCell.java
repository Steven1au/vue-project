public class ParkCell extends FunctionCell {

	public ParkCell(String name) {
		super(name);
	}
	
	public ParkCell() {
		super("Park");
	}
	
	@Override
	public void event(Player p, Cell[] cells) {
		p.setInPark(true);
	}
    //TODO add some other methods if necessary
}

