import java.util.Scanner;

public class PropertyCell extends Cell {
    protected int baseCost;
    protected Player owner = null;
    int house = 0;
    
	@Override
	public void event(Player p, Cell[] cells) {
		System.out.println("you have landed on " + this.name+"!" );
		if(this.owner == null) {
			System.out.println("Do you want to buy the this for " + baseCost + "? (y/n)");
		    Scanner s = new Scanner(System.in);
	        if (s.next().equals("y")) {
	        	p.charge(baseCost);
	        	this.owner = p;
	        	System.out.println("you have bought this land!");
	        }
		}else {
			hasOwnerEvent(p);
		}
		
		
	}
	
	public void hasOwnerEvent(Player p) {
		if(owner.getName().equals(p.getName())) {
			int cost = baseCost/5;
			System.out.println("Do you want to build a house for this land for "+cost+"? (y/n)");
		    Scanner s = new Scanner(System.in);
	        if (s.next().equals("y")) {
	        	if(p.getMoney() > cost) {
	        		p.charge(baseCost/5);
	        		house ++;
	        		System.out.println("you have built a house!");
	        	}else {
	        		System.out.println("you don't have enough money!");
	        	}
	        }
		}else {
			if(this.owner.isInPark() == true) {
				System.out.println(this.owner.getName() + " is in the Park. Free parking.");
		        return;
			}
			int payRent = getRent(p);
			System.out.println(p.getName() + " have paid " +this.owner.getName() + " $" + payRent);
		}
	}
	

    /**
     * Return the owner of the property
     * @return owner
     */
    public Player getOwner() { 
        //TODO
    	return this.owner;
     }
     /**
      * Constructor
      */
    public PropertyCell(String name, int baseCost) {
        //TODO
    	super(name);
    	this.baseCost = baseCost;
    	
    }
    /**
     * Return the cost of the property cell
     * @return the base cost of the property cell.
     */
    public int getCost() { 
        //TODO
    	return this.baseCost;
    }
    /**
     * Return number of houses built on this property cell.
     * @return the number of houses.
     */
    public int getHouse() { 
        //TODO
    	return this.house;
    }


    /**
     * Return a specific format of string. See the assignment webpage
     * for more details
     * @return the specific string of the property cell/
     */
    @Override
    public String toString() {
        //TODOFSC owned by - : 800
    	return this.name + " owned by " + (this.owner == null ? "-":this.owner.getName()) +" : " + this.baseCost * (1 + house * 0.5) + (house == 0?" ":(" House :" + house));
    }

    /**
     * Return the rent charged against this player. The formula for an ordinary cell is
     * baseCost * (1 + house * 0.5) rounding the nearest integer.
     *
     * @param p - The player who is charged. p is irrelevant in this case.
     * @return The rent.
     */
    public int getRent(Player p) {
        //TODO
    	int rent = (int) Math.round(baseCost * (1 + house * 0.5));
    	p.charge(rent);
    	this.owner.charge(-rent);
    	return rent;
    }

}
