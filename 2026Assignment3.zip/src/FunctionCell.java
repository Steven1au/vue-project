public class FunctionCell extends Cell {

	public FunctionCell(String name) {
		super(name);
	}
    //TODO add some other methods if necessary

	@Override
	public void event(Player p, Cell[] cells) {
		// TODO Auto-generated method stub
		
	}
    
}


