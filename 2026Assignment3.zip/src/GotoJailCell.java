public class GotoJailCell extends FunctionCell {

	public GotoJailCell(String name) {
		super(name);
	}
	
	public GotoJailCell() {
		super("Go to Jail!");
	}
	@Override
	public void event(Player p, Cell[] cells) {
		super.event(p, cells);
		p.putToJail();
	}
	
    //TODO add some other methods if necessary
}
